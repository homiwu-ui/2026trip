---
name: shutdown
description: 收工同步。當對話要結束、換電腦、或使用者說「收工」、「結束」、「同步」、「先到這裡」，自動三方同步：git commit + push + 更新 Obsidian 每日筆記 + 知識庫記錄
---

# 收工同步助手

對話結束前，把今天的工作存到三個家：
- **GitHub**：commit + push 本 repo 變動
- **Obsidian 每日筆記**：填入今日完成事項
- **Obsidian 知識庫**：更新 log.md 記錄今日操作

## 收工 SOP

### 步驟 1：盤點今天做了什麼
從對話歷史摘要：完成的檔案、新增/修改的內容、做出的決策。

### 步驟 2：更新今日每日筆記
讀取 `每日筆記/<今天日期>.md`，在「🏫 工作」區追加今日完成事項：

每項格式：
- <完成的事>
  ─ 關聯檔案：<檔案路徑>

完成後也檢查「明日優先事項」，如有待辦一併填入。

### 步驟 3：更新 Obsidian 知識庫 log.md
在 `G:\我的雲端硬碟\2nddrain\知識庫\log.md` 最下方加上一筆紀錄：

格式：
```
## YYYY-MM-DD <操作摘要>

**操作類型：** <新增/修改/刪除/初始化/匯入>

**變更內容：**
- <檔案或路徑> — <變更摘要>
- ...

**相關 Clippings：**（若有）
```

使用 `obsidian_patch_note` 或 `obsidian_write_note` 工具操作。

### 步驟 4：Git commit + push
```powershell
git add <今天動到的檔案>
git commit -m "<類型: 摘要>"
git push
```

commit message 格式：
- 類型：`feat` / `fix` / `chore` / `docs` / `refactor`
- 範例：`feat: 新增 14 篇 NotebookLM 匯入筆記`

### 步驟 5：報告狀態
給使用者勾選摘要：

| 平台 | 動作 | 狀態 |
|------|------|:----:|
| GitHub | commit + push | ✅ |
| Obsidian 每日筆記 | 工作區已更新 | ✅ |
| Obsidian 知識庫 | log.md 已更新 | ✅ |

## 不該做的事
- ❌ 沒實質進度也跑同步（只問問題沒改檔）
- ❌ commit 秘密、token、API Key
- ❌ commit message 寫「更新」、「修改」
