---
name: project-init
description: 初始化新專案。當使用者說「初始化」、「開新專案」、「建新工具」、「新專案」、「開始新專案」，從零建立完整的工作環境：GDrive 目錄 + AGENTS.md + .gitignore + git init + GitHub repo (public + Pages) + Obsidian 工作筆記
---

# 專案初始化助手

從零建立一個新的工具專案，設定三個家：
- **GDrive**：工作目錄（自動跨電腦同步）
- **GitHub**：公開 repo + Pages
- **Obsidian**：工作筆記（駕駛艙）

## 初始化 SOP

### 步驟 1：詢問基本資訊
🖐️ 問使用者：
- 「專案名稱？」（英文小寫加連字號，例：`my-classroom-tools`）
- 「放在哪裡？」（預設：`G:\我的雲端硬碟\<專案名>`）
- 「WIP 路徑？」（預設同 GDrive 路徑）

### 步驟 2：建立目錄結構
```powershell
mkdir -p "<使用者給的路徑>"
mkdir -p "<使用者給的路徑>\tools"
```

### 步驟 3：寫入 AGENTS.md
建立 `AGENTS.md`：

```markdown
# <專案名> — 我的工具專案

## 對話開始時請先讀
進度與最近更動都在 Obsidian：`G:\我的雲端硬碟\2nddrain\<專案名>\工作筆記.md`

## 工作模式
- **加新工具**：對 AI 說「我想做一個 XXX」→ 建 `tools/<工具名>/` 子資料夾
- **結束工作**：說「收工」→ 自動三方同步
- **接續工作**：說「開工」→ 讀工作筆記 + 報進度

## 三個家
- 📋 GDrive 工作桌：`<路徑>`
- 🐙 GitHub repo：`homiwu-ui/<專案名>`
- 📘 Obsidian 駕駛艙：`G:\我的雲端硬碟\2nddrain\<專案名>\工作筆記.md`

## 注意事項
- commit 訊息寫清楚做了什麼 + 為什麼
- 收工前說「收工」
```

### 步驟 4：寫入 .gitignore
```
# Google Drive 系統檔
desktop.ini
*.tmp
~$*

# 敏感資料
.env
*.key
credentials.*
.opencode/

# Node.js
node_modules/
package-lock.json
```

### 步驟 5：git init + gh repo create + push
```powershell
cd "<路徑>"
git init
git add AGENTS.md .gitignore
git commit -m "chore: 初始化專案 <專案名>"
gh repo create homiwu-ui/<專案名> --public --source=. --push
```

### 步驟 6：啟用 GitHub Pages
```powershell
gh api repos/homiwu-ui/<專案名>/pages -X POST --input '{"source":{"branch":"master","path":"/"}}' --silent
```

### 步驟 7：建立 Obsidian 工作筆記
使用 `obsidian_write_note` 工具建立 `G:\我的雲端硬碟\2nddrain\<專案名>\工作筆記.md`：

```markdown
---
title: <專案名> 工作筆記
type: 工作筆記
created: <今天日期>
tags:
  - workspace
---

# <專案名> 工作筆記

## ⏯️ 上次做到哪
**最後動作：** 剛初始化
**所在 repo：** [homiwu-ui/<專案名>](https://github.com/homiwu-ui/<專案名>)

## 🛠️ 工具清單
（尚無）

## 🗓️ 最近更動紀錄
| 日期 | 變更摘要 | GDrive | Obsidian | GitHub |
|------|----------|--------|----------|--------|
| <今天日期> | 初始化專案 | ✅ | ✅ | ✅ |

## 🕳️ 踩坑筆記
（之後有坑就記這）
```

### 步驟 8：回報結果
```
✅ <專案名> 初始化完成

| 平台 | 位置 | 狀態 |
|------|------|:----:|
| 📋 GDrive | <路徑> | ✅ |
| 🐙 GitHub | homiwu-ui/<專案名> | ✅ Pages 已啟用 |
| 📘 Obsidian | <專案名>/工作筆記.md | ✅ |
```

## 事後須知
- 初始化只負責建空殼，不裝工具
- 說「我想做一個 XXX」開始加第一個工具
